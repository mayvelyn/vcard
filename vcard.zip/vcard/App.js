import React, { useState } from 'react';
import { StyleSheet, View, Image, Text, ScrollView, Linking, TouchableOpacity, TextInput } from 'react-native';

export default function App() {
  const handleAddressPress = () => {
    Linking.openURL('https://www.google.com/maps/search/?api=1&query=Global+Reciprocal+Colleges');
  };
  
  const handleCalendarPress = () => {
    const eventData = {
      title: 'Appointment',
      startDate: new Date('2023-06-01T14:00:00'),
      endDate: new Date('2023-06-01T15:00:00'),
    };

    const eventUrl = `https://www.google.com/calendar/render?action=TEMPLATE&text=${eventData.title}&dates=${eventData.startDate.toISOString().replace(/[-:]/g, '')}/${eventData.endDate.toISOString().replace(/[-:]/g, '')}&location=Global+Reciprocal+Colleges&details=Appointment+at+Global+Reciprocal+Colleges`;

    Linking.openURL(eventUrl);
  };

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = () => {
    // Handle form submission here
    console.log('Name:', name);
    console.log('Email:', email);
    console.log('Message:', message);
    // You can add further logic for form submission
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      {/* Cover Picture */}
      <Image
        source={{ uri: 'https://i.pinimg.com/564x/fa/7b/6d/fa7b6d08e45a25a097c56dcd9267d4ca.jpg' }}
        style={styles.coverImage}
      />

      {/* Profile Picture */}
      <Image
        source={{ uri: 'https://scontent.xx.fbcdn.net/v/t1.15752-9/440805526_1082190779513747_5021221688079719837_n.jpg?_nc_cat=111&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeH_kZwITngaGhndS--aGu5r5yz6qdYq6sLnLPqp1irqwm2hWEUcB4j-ZHYiuOrq_xc97dODy5YTDoZBe3mXMjhS&_nc_ohc=9TuuE34CYoIQ7kNvgEYCaaE&_nc_oc=Adgzej9nWRF2oYOXOtwC-zbnpHqFdhwL8HR0K6d_X_m-Xt_usyj_jbQUXCbtHO35BZ8n8k4bXtwbh1Umh2sCmm0N&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QER6JgRqjG-6mihIhgGbt1zI3gBB-vznA-AKgFU57GTag&oe=666AEE62' }}
        style={styles.profileImage}
      />

      {/* name */}
      <Text style={styles.nameText}>Mayvelyn C. Cereno</Text>

      {/* Bio */}
      <Text style={styles.bioText}></Text>
      <Text style={styles.bioText}> "The only way to do great work is to love what you do." - Steve Jobs</Text>

      {/* Box Containing Information */}
      <View style={styles.infoBox}>
        {/* Phone Icon */}
        <View style={styles.infoItem}>
          <Text style={styles.infoIcon}>✆</Text>
          <Text style={styles.infoText}>09633024940</Text>
        </View>

        <View style={styles.infoItem}>
          <Text style={styles.infoIcon}>✉</Text>
          <TouchableOpacity onPress={() => Linking.openURL('https://myaccount.google.com/?hl=en&utm_source=OGB&utm_medium=act')}>
            <Text style={styles.infoText}>cerenomayvelyn@gmail.com</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.infoItem}>
          <Text style={styles.infoIcon}>ⓕ</Text>
          <TouchableOpacity onPress={() => Linking.openURL('https://www.facebook.com/mayvelyn.cereno?mibextid=ZbWKwL')}>
            <Text style={styles.infoText}>Mayvelyn Cereno</Text>
          </TouchableOpacity>
        </View>


        {/* College Link */}
        <View style={styles.infoItem}>
          <Text style={styles.infoIcon}>🏢</Text>
          <TouchableOpacity onPress={() => Linking.openURL('https://www.grc.edu.ph/')}>
            <Text style={styles.infoText}>Global Reciprocal Colleges, Caloocan</Text>
          </TouchableOpacity>
        </View>
      </View>
 



            {/* Separated Info Box with Four Pictures */}
      <View style={styles.separatedInfoBox}>
        <Text style={styles.sectionTitle}> Making memories with my favorite people. </Text>
        <View style={styles.pictureGrid}>
          <Image
            source={{ uri: 'https://scontent.xx.fbcdn.net/v/t1.15752-9/440923754_458875776793678_6456139924135505737_n.jpg?_nc_cat=107&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeESNhA_cd0N3yB6EkI3KVVjMFQBnEWR8GswVAGcRZHwa0W2KHKVeDF4dPXKMLdhdUFv3jPgq8wbsKsF5dp3bWu_&_nc_ohc=AfwSCWgaJDIQ7kNvgH4ttsN&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QGpVYxiZQlC2fbfvJPUJ4I7ClXk88Fx9gfN-4rjmQ3J2g&oe=666ACA13' }}
            style={styles.picture}
          />
          <Image
            source={{ uri: 'https://scontent.xx.fbcdn.net/v/t1.15752-9/441229950_1015395593537371_5773956712267684886_n.jpg?_nc_cat=108&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeF9Ge8S1LhKprNK-XZNWcCsJ7WMR52fUtgntYxHnZ9S2Brke2JrSairWG-GcOfhN28V5tXvqtO4i5LJ1V1UC836&_nc_ohc=4RsQJUGqOu0Q7kNvgG_IqjM&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QHq_k0nQUOOySzrdZVkd6vI4UmbAL5TIhlx_7vNnCsXpw&oe=666AE6A9' }}
            style={styles.picture}
          />
          <Image
            source={{ uri: 'https://scontent.xx.fbcdn.net/v/t1.15752-9/440719038_988838509543910_4379523451629619571_n.jpg?_nc_cat=110&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeHYcShW2qg4lTI6YWsJf17CJhurvaats7cmG6u9pq2zt4J7YdYLseZyGLU9GN6IeQJyJAjmBAze4tjST72R_TIt&_nc_ohc=SenD9qX2frIQ7kNvgEG0yE-&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QGHJoTL3i9FS2zvwBXvlyNWnWnkrtv_C5D0x-AkII6zGQ&oe=666ACAF9' }}
            style={styles.picture}
          />
          <Image
            source={{ uri: 'https://scontent.xx.fbcdn.net/v/t1.15752-9/441281251_921462833110856_3202307990550984832_n.jpg?_nc_cat=105&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeHnYd0fDDAsy4JAu6MB51F7vbXliDrQg-C9teWIOtCD4ADDeCIxup5ZLR1PX31Td-orI6rs4mg-CQu_ULwgC-jG&_nc_ohc=2kz5q1gkCAEQ7kNvgHhJe0a&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QGa_gRMphNSYbzJJzGNLJ7YC-uWIBtUBdOmSsYb4ivEew&oe=666AEA71' }}
            style={styles.picture}
          />
          <Image
            source={{ uri: 'https://scontent.xx.fbcdn.net/v/t1.15752-9/440729602_745432380998538_5811842354315034949_n.jpg?_nc_cat=102&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeFP7SzkGVrvH50LRcxh9yGOl8Fzk5TexamXwXOTlN7FqdrXUMFucjOzbjA_r7iDJHT8daHndfzlIgQxNGU_c-iA&_nc_ohc=p2kUP6Io1gkQ7kNvgEHvMLY&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QHA-z_JJNAEy-6Q3UvhEfXiGDi4U3pSojHNbAsDpJFL5w&oe=666AE336' }}
            style={styles.picture}
          />
          <Image
            source={{ uri: 'https://scontent.xx.fbcdn.net/v/t1.15752-9/440862861_359762827087798_328942811018874544_n.jpg?_nc_cat=111&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeGyWNNvZCK69rtuiueP8Fy70RF4FRC0MIXREXgVELQwhb4MKIiYTq2gPqiXrQL_iLHXbrEtgQAGyKgQznhPPg8o&_nc_ohc=p1Fw5Zojj_YQ7kNvgGvsTfv&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QEvZBTpgNW1Gk9-1o4SvR0RYQOBG03fbsWWmi3WoVJYTA&oe=666AF068' }}
            style={styles.picture}
          />
          <Image
            source={{ uri: 'https://scontent.xx.fbcdn.net/v/t1.15752-9/440740421_1010761487373234_7664690052274124092_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeFdOpmUzISrYDwrWx-MRn_qBhLKnZTFQ8oGEsqdlMVDygi7QpDcbt_nCYFiHmYAbDJkYtdj67NxtjNyWGESIf9p&_nc_ohc=aSnxUKLRgOEQ7kNvgEjvCDV&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QEKNrR8UxofXTARXizKeIAVvSIYxkcO2BmcB_00tybqIg&oe=666AD43C' }}
            style={styles.picture}
          />
          <Image
            source={{ uri: 'https://scontent.xx.fbcdn.net/v/t1.15752-9/441006775_472333428472234_5122989633318385939_n.jpg?_nc_cat=110&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeGgpcWFDp-tYP9E6nw0tGfYO5nTUklsoEw7mdNSSWygTAvPdo5FDefgCT989Vy1hpW0gPjAp5CwjTGguWHue357&_nc_ohc=GVhobCF1ZUwQ7kNvgGYz_Uj&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QG9Vu13mlCity-8Q_rsMmK2Rwk9lB8joSFa0QdvjUWdoQ&oe=666AC2FA' }}
            style={styles.picture}
          />
          
        </View>
      </View>


      <View style={[styles.infoBox, { backgroundColor: 'beige' }]}>
        <View style={styles.infoItem}>
          <Text style={styles.infoIcon}>🗺️</Text>
          <Text style={[styles.infoText, { color: 'black', textDecorationLine: 'underline' }]} onPress={handleAddressPress}>
            Global Reciprocal Colleges, Caloocan City, Metro Manila, Philippines
          </Text>
        </View>
        <TouchableOpacity style={styles.infoItem} onPress={handleCalendarPress}>
          <Text style={styles.infoIcon}>𝄜 </Text>
          <Text style={[styles.infoText, { color: 'black', textDecorationLine: 'underline' }]}>Add to Calendar</Text>
        </TouchableOpacity>
      </View>

      {/* Contact Form */}
      <View style={styles.contactForm}>
        <TextInput
          style={styles.input}
          placeholder="Name"
          value={name}
          onChangeText={setName}
        />
        <TextInput
          style={styles.input}
          placeholder="Email"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
        />
        <TextInput
          style={[styles.input, { height: 100 }]}
          placeholder="Description"
          value={message}
          onChangeText={setMessage}
          multiline
        />

        <TouchableOpacity style={styles.button} onPress={handleSubmit}>
          <Text style={styles.buttonText}>Submit</Text>
        </TouchableOpacity>
      </View>

      

    </ScrollView>
  );
}


const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#E6ACD7',
    alignItems: 'center',
    justifyContent: 'center',
  },
  coverImage: {
    width: '100%',
    height: 300,
    resizeMode: 'cover',
  },
  profileImage: {
    width: 200,
    height: 150,
    borderRadius: 50,
    marginTop: -50,
    borderWidth: 2,
    borderColor: 'beige',
  },
  nameText: {
    fontSize: 17,
    marginVertical: 10,
    color: 'black',
  },
  bioText: {
    fontSize: 10,
    marginVertical: 10,
    color: 'black',
  },
  infoBox: {
    backgroundColor: 'beige',
    padding: 10,
    borderRadius: 10,
    marginTop: 20,
    width: '80%',
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 8,
  },
  infoIcon: {
    fontSize: 18,
    marginRight: 10,
    color: 'purple',
  },
  infoText: {
    fontSize: 12,
    color: 'black',
  },
  separatedInfoBox: {
    backgroundColor: 'beige',
    padding: 10,
    borderRadius: 10,
    marginTop: 20,
    width: '80%',
    alignItems: 'center',
  },
  pictureGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  picture: {
    width: 100,
    height: 100,
    borderRadius: 10,
    margin: 5,
  },
  contactForm: {
    marginTop: 20,
    width: '80%',
  },
  input: {
    width: '100%',
    height: 40,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    marginBottom: 10,
    padding: 10,
  },
  button: {
    backgroundColor: '#965C87',
    padding: 10,
    borderRadius: 5,
    marginTop: 20,
  },
  buttonText: {
    color: 'white',
    textAlign: 'center',
  },
});

